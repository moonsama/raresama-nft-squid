module.exports = class Data1669374913981 {
  name = 'Data1669374913981'

  async up(db) {

  }

  async down(db) {

  }
}
