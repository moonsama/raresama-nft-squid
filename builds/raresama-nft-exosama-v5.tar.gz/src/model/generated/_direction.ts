export enum Direction {
    FROM = "FROM",
    TO = "TO",
}
